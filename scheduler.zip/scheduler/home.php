<!DOCTYPE html>
<html>
    <head>
        <meta charset = "utf-8">
        <!-- 페이지 이름 -->
        <title> 데이터베이스  </title> 
        <!-- 연결한 css 파일 부분 -->
        <link rel = "stylesheet" type="text/css" href="home_style.css">  
    </head>
    <body>
        <div class="header">
            <img src="image.jpg" width="100">
            <h1>아동 센터 시간표 작성 프로그램</h1>
            <img src="image.jpg" width="100">
        </div>
        <div class="header-buttons">
            <button onclick="window.location.href='signup.php'">회원가입</button>
            <button onclick="window.location.href='login.php'">로그인</button>
        </div>
    </body>
</html>
