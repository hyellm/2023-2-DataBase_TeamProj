<?php
    $con=mysqli_connect("localhost", "root", "0708", "scheduler") or die("MySQL 접속 실패 !!");

    $program_serial=$_POST["program_serial"];
    $cate_serial = $_POST["cate_serial"];


    $sql = " INSERT INTO program_category 
            VALUES('".$program_serial."', '".$cate_serial."')";
    $ret = mysqli_query($con,$sql);

    echo "<h2> 프로그램 카테고리 추가 </h2>";
    if($ret){
        echo "데이터가 성공적으로 추가됨.";
        header('Location: side_bar.php?tab=program');

    }
    else{
        echo "데이터 추가 실패!<br>";
        echo "실패 원인 :".mysqli_error($con);   
    }

    mysqli_close($con);

    echo "<br> <a href='side_bar.php?tab=program'> <--프로그램으로</a> ";
   
?>
