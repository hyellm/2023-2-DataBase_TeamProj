<HTML>
    <HEAD>
        <META http-equiv="content-type" content="text/html; charset=utf-8">
    </HEAD>
    <BODY>

    <h1>센터 시간 정보 추가</h1>
    <FORM method="post" action="center_time_insert_res.php">
        요일 : <INPUT TYPE="text" NAME="day"> <br>
        시작 시간 : <INPUT TYPE="time" NAME="start_time"> <br>
        종료 시간 : <INPUT TYPE="time" NAME="finish_time"><br>
        <BR><BR>
        <INPUT TYPE="submit" VALUE="시간 입력">
    </FORM>
    </BODY>
</HTML>